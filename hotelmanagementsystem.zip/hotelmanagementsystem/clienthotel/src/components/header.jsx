import React, { useState } from "react";

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <nav className="bg-black p-4 fixed top-0 left-0 w-full z-10">
      <div className="flex items-center justify-between">
        {/* Logo */}
        <div className="text-white text-2xl"><b>Hotel</b></div>

        {/* Mobile menu icon */}
        <div className="lg:hidden">
          <button onClick={toggleMenu} className="text-white">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-6 h-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:flex space-x-6">
          <a
            href="/"
            className="text-white hover:text-yellow-400 transition-colors duration-300"
          >
            Home
          </a>
          <a
            href="/about"
            className="text-white hover:text-yellow-400 transition-colors duration-300"
          >
            About
          </a>
          <a
            href="/Rooms"
            className="text-white hover:text-yellow-400 transition-colors duration-300"
          >
            Rooms
          </a>
          <a
            href="/contact"
            className="text-white hover:text-yellow-400 transition-colors duration-300"
          >
            Contact
          </a>
        </div>
      </div>

      {/* Mobile Menu (Side slide-in) */}
      <div
        className={`lg:hidden fixed top-0 right-0 bg-black w-3/4 h-full transform transition-transform duration-300 ${menuOpen ? "translate-x-0" : "translate-x-full"}`}
      >
        <div className="flex flex-col items-center space-y-6 mt-16">
          {/* Close Button */}
          <button
            onClick={toggleMenu}
            className="text-white absolute top-4 right-4 text-3xl"
          >
            &times;
          </button>

          <a
            href="/"
            className="text-white text-2xl hover:text-yellow-400 transition-colors duration-300"
          >
            Home
          </a>
          <a
            href="/about"
            className="text-white text-2xl hover:text-yellow-400 transition-colors duration-300"
          >
            About
          </a>
          <a
            href="/Rooms"
            className="text-white text-2xl hover:text-yellow-400 transition-colors duration-300"
          >
            Rooms
          </a>
          <a
            href="/contact"
            className="text-white text-2xl hover:text-yellow-400 transition-colors duration-300"
          >
            Contact
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

