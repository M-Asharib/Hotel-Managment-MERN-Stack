import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom"; // For dynamic routing

const RoomDetailsPage = () => {
  const { roomId } = useParams(); // Get the roomId from the URL
  const [room, setRoom] = useState(null);

  const rooms = [
    {
      id: 1,
      name: "Deluxe Room",
      price: 200,
      description: "Perfect for couples or solo travelers. Includes a king-size bed, balcony, and luxury amenities.",
      image: "https://images.pexels.com/photos/279746/pexels-photo-279746.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", 
      details: "This is a luxurious room with stunning views of the city skyline. Features include an en-suite bathroom, a balcony, and a king-size bed.",
    },
    {
      id: 2,
      name: "Superior Room",
      price: 150,
      description: "Spacious and elegant, with modern decor, a queen-size bed, and an amazing city view.",
      image: "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",  
      details: "A sophisticated room with a beautiful city view, queen-size bed, and modern amenities.",
    },
    {
      id: 3,
      name: "Standard Room",
      price: 100,
      description: "Affordable and cozy, ideal for short stays. Includes a double bed and essential amenities.",
      image: "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",  
      details: "A comfortable and affordable option for travelers who need a simple and clean room for a short stay.",
    },
  ];

  useEffect(() => {
    const foundRoom = rooms.find((room) => room.id === parseInt(roomId));
    setRoom(foundRoom);
  }, [roomId]);

  if (!room) {
    return <div>Room not found</div>;
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto text-center">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden max-w-3xl mx-auto">
          <img src={room.image} alt={room.name} className="w-full h-64 object-cover" />
          <div className="p-6">
            <h2 className="text-3xl font-semibold text-gray-800 mb-4">{room.name}</h2>
            <p className="text-lg text-gray-600 mb-4">{room.description}</p>
            <p className="text-md text-gray-600 mb-4">{room.details}</p>
            <div className="flex items-center justify-between mt-4">
              <span className="text-xl font-semibold text-yellow-400">${room.price} / night</span>
              <a href="/book-now" className="bg-yellow-400 text-black py-2 px-6 rounded-lg transition-transform transform hover:scale-105 duration-300">
                Book Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RoomDetailsPage;
