import { BrowserRouter, Routes, Route, } from 'react-router-dom';

import Register from './register';
import Home from './home';
import Login from './login';
import AboutPage from './about';
import ContactPage from './contact';
import RoomPage from './room';
import RoomDetailsPage from './components/roomdetail';


function App() {
 

  return (
    <BrowserRouter>
      {/* Navbar */}
  

      {/* Routes */}
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/register' element={<Register />} />
        <Route path='/login' element={<Login />} />
        <Route path='/about' element={<AboutPage />} />
        <Route path='/contact' element={<ContactPage />} />
        <Route path='/rooms' element={<RoomPage />} />
        <Route path="/room/:roomId" element={<RoomDetailsPage />} />
        
      </Routes>
    </BrowserRouter>
  );
}

export default App;