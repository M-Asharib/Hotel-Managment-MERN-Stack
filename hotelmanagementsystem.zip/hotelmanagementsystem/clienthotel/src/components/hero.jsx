import React from "react";
import { Link } from "react-router-dom"; // Import Link from react-router-dom

const HeroSection = () => {
  return (
    <section
      className="relative w-full h-screen bg-cover bg-center pt-24"  // Added pt-24 for margin-top to prevent overlap with navbar
      style={{
        backgroundImage: "url('https://images.pexels.com/photos/18524069/pexels-photo-18524069/free-photo-of-a-hotel-sign-with-the-word-hotel-in-silver.jpeg?auto=compress&cs=tinysrgb&w=600')"
      }}
    >
      <div className="absolute inset-0 bg-black opacity-50"></div> {/* Dark overlay for text contrast */}
      
      <div className="container mx-auto text-center relative z-0">
        <div className="flex flex-col items-center justify-center h-full px-4 py-24">
          {/* Heading */}
          <h1 className="text-white text-5xl md:text-6xl font-bold mb-4">
            Welcome to <span className="text-yellow-400">Hotel</span>
          </h1>

          {/* Subheading */}
          <p className="text-white text-lg md:text-2xl mb-6 max-w-3xl mx-auto">
            Discover luxury, comfort, and world-class service at our exclusive resort. Your perfect stay awaits.
          </p>

          {/* CTA Button */}
          <Link to="/rooms">
            <button className="bg-yellow-400 text-black py-3 px-8 text-lg font-semibold rounded-full transition-transform transform hover:scale-105 duration-300">
              Book Now
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
