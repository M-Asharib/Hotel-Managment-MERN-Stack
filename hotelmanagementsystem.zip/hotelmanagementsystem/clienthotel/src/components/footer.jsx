import React from 'react';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="bg-black text-white py-10">
      <div className="container mx-auto px-6">
        <div className="lg:flex lg:justify-between lg:space-x-12">
          {/* Left - Logo and Contact Info */}
          <div className="mb-8 lg:mb-0">
            <div className="text-2xl font-semibold mb-4">MyApp Hotel</div>
            <p className="text-lg mb-4">123 Main Street, City Center</p>
            <p className="text-lg mb-4">Phone: (123) 456-7890</p>
            <p className="text-lg">Email: contact@myapphotel.com</p>
          </div>

          {/* Middle - Quick Links */}
          <div className="mb-8 lg:mb-0">
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/" className="hover:text-gold-400">Home</a></li>
              <li><a href="/about" className="hover:text-gold-400">About Us</a></li>
              <li><a href="/Rooms" className="hover:text-gold-400">Rooms</a></li>
              <li><a href="/contact" className="hover:text-gold-400">Contact</a></li>
            </ul>
          </div>

          {/* Right - Social Media Links */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gold-400">
                <FaFacebook size={30} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gold-400">
                <FaTwitter size={30} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gold-400">
                <FaInstagram size={30} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gold-400">
                <FaLinkedin size={30} />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom - Copyright */}
        <div className="text-center bg-yellow-600 mt-8">
          <p className="text-sm">© 2025 MyApp Hotel. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
