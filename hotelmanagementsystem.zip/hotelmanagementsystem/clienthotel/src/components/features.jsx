import React from "react";

const BadgesSection = () => {
  return (
    <section className="bg-gray-100 py-16">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-8">Our Hotel Features & Awards</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
          {/* Feature Badge 1 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M3 10h18M3 6h18M3 14h18M3 18h18"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">Free Wi-Fi</h3>
            <p className="text-gray-500">Stay connected with high-speed internet across all rooms.</p>
          </div>

          {/* Feature Badge 2 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 6v6l4 2M6 12l4-2V6M12 18v-6l4-2M6 12l4-2V6"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">24/7 Room Service</h3>
            <p className="text-gray-500">Enjoy delicious meals and drinks delivered to your room at any time.</p>
          </div>

          {/* Feature Badge 3 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M3 12l1.086 1.086A5.988 5.988 0 0112 6a5.988 5.988 0 017.914 7.086L21 12l-1.086-1.086A5.988 5.988 0 0112 18a5.988 5.988 0 01-7.914-7.086L3 12z"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">Swimming Pool</h3>
            <p className="text-gray-500">Relax and enjoy our luxurious pool with a breathtaking view.</p>
          </div>

          {/* Feature Badge 4 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M19.5 12l-7.5 6-7.5-6M19.5 6l-7.5 6-7.5-6"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">Free Breakfast</h3>
            <p className="text-gray-500">Start your day right with a complimentary gourmet breakfast.</p>
          </div>

          {/* Award Badge 1 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 8V6m0 12v-2m4-6h2m-12 0h2m12 4h2M4 14h2m10 4H8"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">Best Hotel Award</h3>
            <p className="text-gray-500">Voted the best luxury hotel in the region, 2023.</p>
          </div>

          {/* Award Badge 2 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">Top Rated Hotel</h3>
            <p className="text-gray-500">Proudly holding the highest customer ratings for comfort and service.</p>
          </div>

          {/* Award Badge 3 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 6v6l4 2M6 12l4-2V6M12 18v-6l4-2M6 12l4-2V6"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">Luxury Experience</h3>
            <p className="text-gray-500">Experience luxury, elegance, and top-tier amenities with every stay.</p>
          </div>

          {/* Award Badge 4 */}
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-16 h-16 mx-auto text-yellow-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 8V6m0 12v-2m4-6h2m-12 0h2m12 4h2M4 14h2m10 4H8"
              />
            </svg>
            <h3 className="text-xl font-semibold text-gray-800 mt-4">Award Winning Spa</h3>
            <p className="text-gray-500">Relax and rejuvenate at our renowned award-winning spa and wellness center.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BadgesSection;
