import React from "react";

const FacilitiesSection = () => {
  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold mb-8">Our Facilities & Amenities</h2>
        <p className="text-lg mb-12">We offer a wide range of services to make your stay comfortable and enjoyable.</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Facility 1 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="w-12 h-12 text-yellow-500 mx-auto"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 9V5m0 4h4m-4 0H8m0 4h4m0 4h-4m-4 4h4m0 0v4m0 0h4m0 0h-4m4-4v4"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Pool</h3>
            <p className="text-gray-600">Relax and unwind in our stunning outdoor pool, available year-round.</p>
          </div>

          {/* Facility 2 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="w-12 h-12 text-yellow-500 mx-auto"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M3 12h6m0 0l3-3m-3 3l3 3m4-6h3M5 5l2 2m0 0L5 9"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Gym</h3>
            <p className="text-gray-600">Stay fit and energized at our fully-equipped, 24-hour fitness center.</p>
          </div>

          {/* Facility 3 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="w-12 h-12 text-yellow-500 mx-auto"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M9 9l3 3l3-3m0 0l3 3l3-3m0 6l-3 3l-3-3m0 0l-3 3l-3-3"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Restaurant</h3>
            <p className="text-gray-600">Indulge in gourmet dining at our on-site restaurant, offering international cuisine.</p>
          </div>

          {/* Facility 4 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="w-12 h-12 text-yellow-500 mx-auto"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M20 20l-6-6M4 4l16 16m-2 4h-2v2h2v-2z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Spa</h3>
            <p className="text-gray-600">Pamper yourself with a rejuvenating experience at our luxurious spa.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FacilitiesSection;
