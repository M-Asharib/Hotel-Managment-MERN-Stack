const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const UserModel = require('../models/User');
const dotenv = require('dotenv');


dotenv.config(); // Load environment variables

dotenv.config();
exports.Hello = async (req, res) => {
    try {
        // You can access any data from the request body, query parameters, etc.
        // Example: const { name } = req.body;
        
        // Respond with a message, you can customize this.
        res.status(200).send('Hello World');
    } catch (err) {
        res.status(500).send('Server Error');
    }
};



exports.register = async (req, res) => {
    const { name, email, password } = req.body;

    try {
        // Check if the user already exists
        const existingUser = await UserModel.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "Email already taken" });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create a new user
        const newUser = await UserModel.create({ name, email, password: hashedPassword });

        // Respond with success message
        res.json({ message: "User registered successfully", user: newUser });

    } catch (err) {
        console.error("Error registering user:", err);  // Log the error for debugging
        res.status(500).json({ error: "Error registering user", details: err });
    }
};



// Login and issue a tokeconst bcrypt = require('bcryptjs');

exports.login = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Find user by username
        const user = await User.findOne({ username });

        if (!user) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        // Compare the entered password with the stored hashed password
        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        // Create a JWT token with the user's ID and role
        const token = jwt.sign(
            { userId: user._id, role: user.role },
            process.env.JWT_SECRET, // Secret from environment variables
            { expiresIn: '1h' } // Token expiration time
        );

        // Send the token as a JSON response
        return res.json({ token });
    } catch (err) {
        // Handle server errors
        console.error(err);
        return res.status(500).json({ message: 'Server error' });
    }
};



// Middleware to protect routes
exports.protect = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];

    if (!token) return res.status(401).send('No token, authorization denied');

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        res.status(401).send('Token is not valid');
    }
};

// Middleware for role-based access control
exports.authorize = (...roles) => (req, res, next) => {
    if (!roles.includes(req.user.role)) {
        return res.status(403).send('Access denied');
    }
    next();
};
