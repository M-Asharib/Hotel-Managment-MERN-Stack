import React from "react";
import RoomsPricingSection from "./components/rooms";

const RoomPage = () => {
 
  return (
    <>
    <RoomsPricingSection roomLimit={12} />
    </>
  );
};

export default RoomPage;
