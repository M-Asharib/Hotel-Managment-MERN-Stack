import React from "react";

const LocationSection = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold mb-8">Find Us</h2>
        <p className="text-lg mb-12">We are conveniently located in the heart of the city, offering easy access to all major attractions.</p>

        <div className="lg:flex lg:justify-center">
          {/* Left - Hotel Location & Nearby Attractions */}
          <div className="lg:w-1/3 lg:mr-8">
            <h3 className="text-2xl font-semibold mb-4">Hotel Location</h3>
            <p className="text-lg mb-6">
              Our hotel is located in the city center, close to shopping districts, museums, and parks. We're a short distance from the major transport stations for easy access to the rest of the city.
            </p>

            {/* Nearby Attractions */}
            <h4 className="text-xl font-semibold mb-4">Nearby Attractions</h4>
            <ul className="text-lg text-gray-600">
              <li>City Museum - 5 minutes walk</li>
              <li>Central Park - 10 minutes by car</li>
              <li>Famous Shopping Street - 3 minutes walk</li>
              <li>Local Food Market - 8 minutes by foot</li>
            </ul>
          </div>

          {/* Right - Google Map Embedding */}
          <div className="lg:w-2/3 mt-8 lg:mt-0">
            <div className="relative overflow-hidden pt-[56.25%]">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14482.804918085965!2d67.1775322!3d24.839888999999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1739651886978!5m2!1sen!2s" width="800" height="450"  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LocationSection;
