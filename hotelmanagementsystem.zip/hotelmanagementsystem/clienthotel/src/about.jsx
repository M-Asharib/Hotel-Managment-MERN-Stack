import React from "react";

const AboutPage = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-8">About Us</h2>

        {/* Company Introduction */}
        <div className="max-w-3xl mx-auto text-lg text-gray-600 mb-8">
          <p>
            Welcome to [Your Company Name]! We are a team of passionate individuals dedicated to providing the best experience for our customers.
            Our mission is to make your stay unforgettable by offering high-quality services, top-tier amenities, and a welcoming atmosphere. Whether you're here for business or leisure, we make sure your needs are met with the utmost care.
          </p>
        </div>

        {/* Our Values */}
        <div className="mb-8">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Our Values</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h4 className="text-xl font-semibold text-gray-800 mb-2">Customer-Centric</h4>
              <p className="text-gray-600">
                We prioritize our customers' needs and always strive to exceed their expectations in every aspect of our service.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h4 className="text-xl font-semibold text-gray-800 mb-2">Integrity</h4>
              <p className="text-gray-600">
                We believe in honesty, transparency, and ethical business practices in all of our interactions and operations.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h4 className="text-xl font-semibold text-gray-800 mb-2">Excellence</h4>
              <p className="text-gray-600">
                We aim for excellence in everything we do. Our goal is to provide outstanding services that leave a lasting impression.
              </p>
            </div>
          </div>
        </div>

        {/* Our Team */}
        <div className="mb-8">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Meet the Team</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <img
                src="team-member1.jpg" // Replace with actual team member image
                alt="Team Member 1"
                className="w-32 h-32 rounded-full mx-auto mb-4"
              />
              <h4 className="text-xl font-semibold text-gray-800">John Doe</h4>
              <p className="text-gray-600">CEO & Founder</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <img
                src="team-member2.jpg" // Replace with actual team member image
                alt="Team Member 2"
                className="w-32 h-32 rounded-full mx-auto mb-4"
              />
              <h4 className="text-xl font-semibold text-gray-800">Jane Smith</h4>
              <p className="text-gray-600">Head of Operations</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <img
                src="team-member3.jpg" // Replace with actual team member image
                alt="Team Member 3"
                className="w-32 h-32 rounded-full mx-auto mb-4"
              />
              <h4 className="text-xl font-semibold text-gray-800">David Johnson</h4>
              <p className="text-gray-600">Lead Developer</p>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <div className="bg-yellow-400 py-8 text-white">
          <h3 className="text-2xl font-semibold mb-4">Get in Touch</h3>
          <p className="text-lg mb-4">
            Have questions or want to learn more about us? Feel free to reach out, and we'll be happy to assist you.
          </p>
          <a
            href="/contact"
            className="bg-white text-yellow-400 py-2 px-6 rounded-lg font-semibold transition-transform transform hover:scale-105 duration-300"
          >
            Contact Us
          </a>
        </div>
      </div>
    </section>
  );
};

export default AboutPage;
