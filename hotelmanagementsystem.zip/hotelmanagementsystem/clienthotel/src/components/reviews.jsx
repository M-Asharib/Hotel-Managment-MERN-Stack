import React from "react";

const ReviewsSection = () => {
  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-8">Customer Reviews</h2>

        {/* Review Cards Container */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Review 1 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="w-10 h-10 text-yellow-400"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z"
                />
              </svg>
            </div>
            <p className="text-lg text-gray-600 italic">"The best hotel experience I've ever had! The staff was incredible, and the amenities were top-notch. I highly recommend it to anyone visiting the city."</p>
            <div className="mt-4">
              <span className="text-xl font-semibold text-gray-800">John Doe</span>
              <div className="flex items-center justify-center mt-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-gray-300">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
              </div>
            </div>
          </div>

          {/* Review 2 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="w-10 h-10 text-yellow-400"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z"
                />
              </svg>
            </div>
            <p className="text-lg text-gray-600 italic">"I stayed here for a business trip and was blown away by the service and attention to detail. The rooms were spacious and beautifully designed. Would definitely return!"</p>
            <div className="mt-4">
              <span className="text-xl font-semibold text-gray-800">Jane Smith</span>
              <div className="flex items-center justify-center mt-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-gray-300">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
              </div>
            </div>
          </div>

          {/* Review 3 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="w-10 h-10 text-yellow-400"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z"
                />
              </svg>
            </div>
            <p className="text-lg text-gray-600 italic">"An amazing experience! The rooms were clean, the service was top-notch, and the location was perfect for exploring the city. I can't wait to return!"</p>
            <div className="mt-4">
              <span className="text-xl font-semibold text-gray-800">Michael Lee</span>
              <div className="flex items-center justify-center mt-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-5 h-5 text-yellow-400">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2l1.12 3.6h3.76l-3.04 2.24L14.88 12l-3.04-2.24L12 2z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ReviewsSection;
