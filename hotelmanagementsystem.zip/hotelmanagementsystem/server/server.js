const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const { register, login, protect, authorize, Hello } = require('./controller/authcontroller');

dotenv.config();

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

// Routes

app.post('/register', register);
app.post('/login', login);
app.get('/hello', Hello);
app.get('/protected', protect, (req, res) => res.send('This is a protected route'));
app.get('/admin', protect, authorize('admin'), (req, res) => res.send('Welcome Admin!'));

app.listen(5000, () => console.log('Server running on port 5000'));
