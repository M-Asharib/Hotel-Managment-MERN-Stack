import React from "react";
import { Link } from "react-router-dom";

const RoomsPricingSection = ({ roomLimit }) => {
  // Array of room data
  const rooms = [
    {
      id: 1,
      name: "Deluxe Room",
      price: 200,
      description: "Perfect for couples or solo travelers. Includes a king-size bed, balcony, and luxury amenities.",
      image: "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",  
    },
    {
      id: 2,
      name: "Superior Room",
      price: 150,
      description: "Spacious and elegant, with modern decor, a queen-size bed, and an amazing city view.",
      image: "https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",  
    },
    {
      id: 3,
      name: "Standard Room",
      price: 100,
      description: "Affordable and cozy, ideal for short stays. Includes a double bed and essential amenities.",
      image: "https://images.pexels.com/photos/279746/pexels-photo-279746.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",  
    },
    // You can add more rooms if needed
  ];

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-8">Our Rooms & Pricing</h2>

        {/* Room Cards Container */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Map through the rooms array and create a card for each room */}
          {rooms.slice(0, roomLimit).map((room) => (
            <Link to={`/room/${room.id}`} key={room.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img
                src={room.image}  // Dynamic image source
                alt={room.name}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-2xl font-semibold text-gray-800">{room.name}</h3>
                <p className="text-lg text-gray-600 mt-2">{room.description}</p>
                <div className="flex items-center justify-between mt-4">
                  <span className="text-xl font-semibold text-yellow-400">${room.price} / night</span>
                  <button className="bg-yellow-400 text-black py-2 px-6 rounded-lg transition-transform transform hover:scale-105 duration-300">
                    Book Now
                  </button>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

// Default value for roomLimit (optional)
RoomsPricingSection.defaultProps = {
  roomLimit: 3,  // Show 3 rooms by default if no roomLimit is passed
};

export default RoomsPricingSection;
