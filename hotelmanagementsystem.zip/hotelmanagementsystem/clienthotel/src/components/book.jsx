import React from "react";
import { Link } from "react-router-dom"; // Import Link from react-router-dom

const BookYourStaySection = () => {
  return (
    <section className="py-16 bg-yellow-500 text-white">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold mb-4">Ready to Book Your Stay?</h2>
        <p className="text-lg mb-8">Don't miss out on the opportunity to stay at our luxurious hotel. Book now and enjoy a world-class experience.</p>

        {/* Booking CTA */}
        <div className="flex justify-center space-x-4">
          {/* Link to booking page */}
          <Link to="/rooms">
            <button className="bg-gold-500 text-white px-8 py-3 rounded-full text-xl hover:bg-gold-600 transition duration-300">
              Book Now
            </button>
          </Link>

          {/* Link to Contact Us page */}
          <Link to="/contact">
            <button className="bg-white text-black px-8 py-3 rounded-full text-xl border-2 border-white hover:bg-gray-100 transition duration-300">
              <b>Contact Us</b>
            </button>
          </Link>
        </div>

        <div className="mt-12">
          <h3 className="text-2xl font-semibold mb-4">Special Offer: 20% Off for a Limited Time!</h3>
          <p className="text-lg">Make your reservation today and take advantage of our exclusive discount. Limited rooms available!</p>
        </div>
      </div>
    </section>
  );
};

export default BookYourStaySection;
