import BookYourStaySection from "./components/book";
import FacilitiesSection from "./components/facilies";
import BadgesSection from "./components/features";
import HeroSection from "./components/hero";
import LocationSection from "./components/location";
import ReviewsSection from "./components/reviews";
import RoomsPricingSection from "./components/rooms";

export default function Home() {

  return (
    <>
    <HeroSection/>
    <BadgesSection/>
    <RoomsPricingSection roomLimit={3} />
    <BookYourStaySection/>
    <ReviewsSection/>
    <FacilitiesSection/>
    <LocationSection/>
    </>
  );
}
